-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 05, 2016 at 05:01 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `examscoring`
--

-- --------------------------------------------------------

--
-- Table structure for table `attempts`
--

CREATE TABLE IF NOT EXISTS `attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `qid` varchar(255) NOT NULL,
  `question` text NOT NULL,
  `response` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `attempts`
--

INSERT INTO `attempts` (`id`, `user`, `qid`, `question`, `response`) VALUES
(1, 'user1', '1', 'Define a computer.', ''),
(2, 'user1', '3', 'define a computer hardware.', ''),
(3, 'user1', '2', 'What is a data ?', ''),
(4, 'user2', '2', 'What is a data ?', ''),
(5, 'user2', '3', 'define a computer hardware.', ''),
(6, 'user2', '1', 'Define a computer.', ''),
(10, 'user3', '3', 'define a computer hardware.', ''),
(11, 'user3', '1', 'Define a computer.', ''),
(12, 'user3', '2', 'What is a data ?', ''),
(13, 'testpo', '3', 'define a computer hardware.', ''),
(14, 'testpo', '2', 'What is a data ?', ''),
(15, 'testpo', '1', 'Define a computer.', '');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `answer`, `keywords`) VALUES
(1, 'Define a computer.', 'a computer is an electronic device that accept data, process, store and produce output', 'accept, computer, electronic device, electronic machine, process, store, produce, output, information, electromechanical, output'),
(2, 'What is a data ?', 'a raw fact or figure that requires proccessing. or unprocessed information', 'raw, fact, processing, unprocessed information'),
(3, 'define a computer hardware.', 'the physical components that makes up a computer system', 'physical, component, computer, computer system');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `type` varchar(10) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `type`, `fullname`) VALUES
(1, 'admin', 'admin', 'admin', NULL),
(2, 'user1', 'userpass', 'user', 'temitope ogunyomi'),
(3, 'user2', 'testad', 'user', 'ade tested'),
(5, 'user3', 'user3pass', 'user', 'test user'),
(6, 'testpo', 'testpo', 'user', 'teniola williams');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
