/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ess_bmsm;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Random;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author hp
 */
public class Login extends javax.swing.JFrame {

    /**
     * Creates new form Login
     */
    public Login() {
        initComponents();

        if (log_id == 1) {
            jTextField1.setText("");
            jPasswordField1.setText("");
            jPasswordField1.setVisible(true);
            jLabel3.setVisible(true);
        } else {
            jTextField1.setText("");
            jPasswordField1.setText("");
            jPasswordField1.setVisible(true);
            jLabel3.setVisible(true);
        }
        ESS_BMSM_Home.toCenter(this);
    }
    public static Integer log_id = 0;
    Test tst;
    Admin amn;
    RegisterPage reg;
    ESS_BMSM_Home home;
    public static Connection con;
    public static Statement st;
    public static ResultSet rs;
    public static String sqlQuery, pswd, sqlQuery1, type;
    public static DefaultTableModel dtm;
    public static ResultSetMetaData md;
    javax.swing.JOptionPane jp = new javax.swing.JOptionPane();
    Integer yes = jp.YES_OPTION, no = jp.NO_OPTION, im = jp.INFORMATION_MESSAGE, wm = jp.WARNING_MESSAGE, qm = jp.QUESTION_MESSAGE, dec = jp.YES_NO_OPTION, okC = jp.OK_CANCEL_OPTION, em = jp.ERROR_MESSAGE;

// <editor-fold defaultstate="collapsed" desc="Default Load Codes">  
    private void createLog() {
        File file = new File("C:\\Duplicate_Log\\");
        try {
            //  boolean create=file.createNewFile();
            if (!file.exists()) {
                if (file.mkdir()) {
                    message("Directory Log Created Successfully", "Message", im);
                } else {
                    message(" Error in Log Creation ", "Message", em);
                }
            } else {
                // message("File Quarantine Already Exists",wm,"Message");
            }
        } catch (Exception ex) {
            message(" Error in Log Creation: " + ex, "Message", im);
            ex.printStackTrace();
        }
    }

    private Integer confirm(String message, String title, Integer ic) {
        return jp.showConfirmDialog(null, message, title, dec, ic);
    }

    private void message(String message, String title, Integer ic) {
        jp.showMessageDialog(null, message, title, ic);
    }

    private String input(String message, String title, Integer ic) {
        return jp.showInputDialog(null, message, title, ic);
    }

    public static void connect(String cnt) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(cnt, "root", "");
            st = con.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void check_sync(String user) {
        int exist_user = Login.countRecs("id", "attempts", "user='" + user + "'");
        if (exist_user <= 0) {
//            Login.registerRecord(user, user, user);
            int questnum = Login.countRecs("id", "questions");
            String[][] questions = null;
            try {
                connect("jdbc:mysql://localhost:3306/examscoring");
                sqlQuery = "SELECT id,question FROM questions;";
                rs = st.executeQuery(sqlQuery);
                ResultSetMetaData rmd = rs.getMetaData();
                questions = new String[questnum][rmd.getColumnCount()];
                int i = 0;
                while (rs.next()) {
                    for (int j = 0; j < questions[0].length; j++) {
                        questions[i][j] = rs.getString(j + 1);
                    }
                    i++;
                }
                rs.close();
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

            String qu = "";
            Integer rnd, count = 0;
            String last[] = Login.getLastRecord("questions", "id", "1");
            do {
                System.out.println("End = " + questnum + " Start= " + 1 + " Length= " + last[0].trim().length());
                rnd = Login.getRandom(0, questnum, last[0].trim().length());
                if (qu.contains("(" + rnd + ")")) {
                    continue;
                }
                System.out.println("Random = " + rnd);
                Login.registerRecord("attempts", "user,qid,question", "'" + user + "','" + questions[rnd][0] + "','" + questions[rnd][1] + "'");
                count++;
                qu += "(" + rnd + ")";
                System.out.println(questions[rnd][0] + "  R  " + rnd + " P " + questions[rnd][1] + " U " + user + " Count= " + count);

                if (count == questnum) {
                    break;
                }
            } while (count < questnum);
            System.out.println(qu);
        }
    }

    public void login() {
        connect("jdbc:mysql://localhost:3306/examscoring");
        String username = jTextField1.getText().toLowerCase().trim();
        String password = jPasswordField1.getText().toLowerCase().trim();
        if (username.trim().isEmpty()) {
            message("Enter Login Username", "Message", wm);
        } else if (password.trim().isEmpty() || password == null) {
            message("Enter Login Password", "Message", wm);
        } else {
            try {
                sqlQuery = "SELECT type,password FROM user WHERE username='" + username + "'";
                rs = st.executeQuery(sqlQuery);
                while (rs.next()) {
                    type = rs.getString(1);
                    pswd = rs.getString(2);
                }
                if (log_id == 1) {
                    
                    Boolean bool = (password.equalsIgnoreCase(pswd)) ? true : false;
                    if (bool == true) {
                        boolean bb=type.equalsIgnoreCase("user")?true:false;
                        if (bb==false) {
                            message("Administrator is not Allow to take Test\n Try login as an Administrator", "Message", im);
                            return;
                        }
                        ESS_BMSM_Home.toCenter(tst);
                        ESS_BMSM_Home.display(tst);
                        tst.user = username;
//                        Login.loadBox2(tst.jComboBox4, "attempts", "qid,question", "user='" + username + "' ORDER BY qid ASC");
                        tst.quest_id=Login.specialLoad(tst.jComboBox4, "attempts", "qid,question", "user='" + username + "' ORDER BY id ASC",tst.quest_id);
                        ESS_BMSM_Home.hideMe(this);
                    } else if (bool == false) {
                        message("Invalid Username or Password", "Message", wm);
                        ESS_BMSM_Home.display(reg);
                        ESS_BMSM_Home.toCenter(reg);
                    }
                } else {

                    Boolean bool = (password.equalsIgnoreCase(pswd)) ? true : false;
                    if (bool == true) {
                        boolean bb=type.equalsIgnoreCase("admin")?true:false;
                        if (bb==false) {
                            message("This User is not an Administrator\n Try login as Student", "Message", im);
                            return;
                        }
                        ESS_BMSM_Home.toCenter(amn);
                        ESS_BMSM_Home.display(amn);
                        amn.user = username;
                        ESS_BMSM_Home.hideMe(this);
                    } else if (bool == false) {
                        message("Invalid Username or Password", "Message", wm);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void loadBox2(JComboBox cmb, String table, String cols) {
        connect("jdbc:mysql://localhost:3306/examscoring");
        cmb.removeAllItems();
        try {
            sqlQuery = "SELECT DISTINCT " + cols + " FROM " + table;
            rs = st.executeQuery(sqlQuery);
            while (rs.next()) {
                cmb.addItem(rs.getString(1) + " " + rs.getString(2));
            }
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void loadBox2(JComboBox cmb, String table, String cols, String filter) {
        connect("jdbc:mysql://localhost:3306/examscoring");
        cmb.removeAllItems();
        try {
            sqlQuery = "SELECT DISTINCT " + cols + " FROM " + table + " WHERE " + filter;
            rs = st.executeQuery(sqlQuery);
            while (rs.next()) {
                cmb.addItem(rs.getString(1) + " " + rs.getString(2));
            }
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
        public static Integer[] specialLoad(JComboBox cmb, String table, String cols, String filter,Integer qstn[]) {
        connect("jdbc:mysql://localhost:3306/examscoring");
        cmb.removeAllItems();
        try {
            sqlQuery = "SELECT COUNT(id) FROM " + table + " WHERE " + filter;
            rs = st.executeQuery(sqlQuery); int ndx=0;
            while (rs.next()) {
                ndx=rs.getInt(1);
            }
            qstn=new Integer[ndx];
            sqlQuery = "SELECT DISTINCT " + cols + " FROM " + table + " WHERE " + filter;
            rs = st.executeQuery(sqlQuery);
            int x=0;
            while (rs.next()) {
                qstn[x]=rs.getInt(1);
                cmb.addItem((x+1)+ ". " + rs.getString(2));
                x++;
            }
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return qstn;
    }

    public static void loadBox(JComboBox cmb, String table, String cols) {
        connect("jdbc:mysql://localhost:3306/examscoring");
        cmb.removeAllItems();
        try {
            sqlQuery = "SELECT DISTINCT " + cols + " FROM " + table;
            rs = st.executeQuery(sqlQuery);
            while (rs.next()) {
                cmb.addItem(rs.getString(1));
            }
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String[] fetch_record(String id, String table, String filter, String lists) {
        String recs[] = null;
        connect("jdbc:mysql://localhost:3306/examscoring");
        try {
            sqlQuery = "SELECT " + lists + " FROM " + table + " WHERE " + filter + "='" + id + "'";
            rs = st.executeQuery(sqlQuery);
            ResultSetMetaData md = rs.getMetaData();
            recs = new String[md.getColumnCount()];
            while (rs.next()) {
                for (int i = 0; i < recs.length; i++) {
                    recs[i] = rs.getString(i + 1);
                }
            }
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return recs;
    }

    public static String[] fetch_record(String table, String lists, String filters) {
        String recs[] = null;
        connect("jdbc:mysql://localhost:3306/examscoring");
        try {
            sqlQuery = "SELECT " + lists + " FROM " + table + " WHERE " + filters;
            rs = st.executeQuery(sqlQuery);
            ResultSetMetaData md = rs.getMetaData();
            recs = new String[md.getColumnCount()];
            while (rs.next()) {
                for (int i = 0; i < recs.length; i++) {
                    recs[i] = rs.getString(i + 1);
                }
            }
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return recs;
    }

    public static String[] load_record(String table, String col, String filters) {
        String recs[] = null;
        connect("jdbc:mysql://localhost:3306/examscoring");
        try {
            sqlQuery = "SELECT COUNT(" + col + ") FROM " + table + " WHERE " + filters;
            rs = st.executeQuery(sqlQuery);
            int count = 0;
            while (rs.next()) {
                count = rs.getInt(1);
            }
            recs = new String[count];
            sqlQuery = "SELECT " + col + " FROM " + table + " WHERE " + filters;
            rs = st.executeQuery(sqlQuery);
            int i = 0;
            while (rs.next()) {
                recs[i] = rs.getString(1);
                i++;
            }
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return recs;
    }

    public static String[][] load_records(String table, String cols, String filters) {
        String recs[][] = null;
        connect("jdbc:mysql://localhost:3306/examscoring");
        try {
            String col = cols.split(",")[0].trim();
            sqlQuery = "SELECT COUNT(" + col + ") FROM " + table + " WHERE " + filters;
            rs = st.executeQuery(sqlQuery);
            int count = 0;
            while (rs.next()) {
                count = rs.getInt(1);
            }
            sqlQuery = "SELECT " + cols + " FROM " + table + " WHERE " + filters;
            rs = st.executeQuery(sqlQuery);
            ResultSetMetaData md = rs.getMetaData();
            recs = new String[count][md.getColumnCount()];
            int i = 0;
            while (rs.next()) {
                for (int j = 0; j < recs.length; j++) {
                    recs[i][j] = rs.getString(j + 1);
                }
                i++;
            }
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return recs;
    }

    public static String[][] load_records(String table, String filter) {
        String recs[][] = null;
        connect("jdbc:mysql://localhost:3306/examscoring");
        try {
            String col = filter.split(",")[0].trim();
            sqlQuery = "SELECT COUNT(" + col + ") FROM " + table;
            rs = st.executeQuery(sqlQuery);
            int count = 0;
            while (rs.next()) {
                count = rs.getInt(1);
            }
            sqlQuery = "SELECT " + filter + " FROM " + table;
            rs = st.executeQuery(sqlQuery);
            ResultSetMetaData md = rs.getMetaData();
            recs = new String[count][md.getColumnCount()];
            int i = 0;
            while (rs.next()) {
                for (int j = 0; j < recs.length; j++) {
                    recs[i][j] = rs.getString(j + 1);
                }
                i++;
            }
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return recs;
    }
//    select * from t order by id desc limit 1

    public static String[] getLastRecord(String table, String col, String limit) {
        String recs[] = null;
        connect("jdbc:mysql://localhost:3306/examscoring");
        try {
            sqlQuery = "SELECT " + col + " FROM " + table + " ORDER BY " + col + " DESC LIMIT " + limit;
            rs = st.executeQuery(sqlQuery);
            ResultSetMetaData md = rs.getMetaData();
            recs = new String[md.getColumnCount()];
            while (rs.next()) {
                for (int i = 0; i < recs.length; i++) {
                    recs[i] = rs.getString(i + 1);
                }
            }
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return recs;
    }

    public static int countRecs(String args, String table) {
        int rec = 0;
        connect("jdbc:mysql://localhost:3306/examscoring");
        try {
            sqlQuery = "SELECT COUNT(" + args + ") FROM " + table;
            rs = st.executeQuery(sqlQuery);
            while (rs.next()) {
                rec = rs.getInt(1);
            }
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return rec;
    }

    public static int countRecs(String args, String table, String filter) {
        int rec = 0;
        connect("jdbc:mysql://localhost:3306/examscoring");
        try {
            sqlQuery = "SELECT COUNT(" + args + ") FROM " + table + " WHERE " + filter;
            rs = st.executeQuery(sqlQuery);
            while (rs.next()) {
                rec = rs.getInt(1);
            }
            rs.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rec;
    }

    public static String[][] fetch_record2(String id, String table, String filter, String lists) {
        String recs[][] = null;
        connect("jdbc:mysql://localhost:3306/examscoring");
        try {
            sqlQuery = "SELECT " + lists + " FROM " + table + " WHERE " + filter + "='" + id + "'";
            rs = st.executeQuery(sqlQuery);
            ResultSetMetaData md = rs.getMetaData();
            recs = new String[2][md.getColumnCount()];
            for (int i = 0; i < recs[0].length; i++) {
                recs[0][i] = md.getColumnName(i + 1);
            }
            while (rs.next()) {
                for (int i = 0; i < recs[0].length; i++) {
                    recs[1][i] = rs.getString(i + 1);
                }
            }
            rs.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return recs;
    }

    public static void loadTable(JTable tbl, String tb, String columns) {
        connect("jdbc:mysql://localhost:3306/examscoring");
        dtm = new DefaultTableModel();
        try {
            sqlQuery = "SELECT " + columns + " FROM " + tb + ";";
            rs = st.executeQuery(sqlQuery);
            md = rs.getMetaData();
            Integer col = md.getColumnCount();
            String column[] = new String[col];
            for (int i = 0; i < col; i++) {
                column[i] = md.getColumnName(i + 1);
                dtm.addColumn(column[i]);
            }
            while (rs.next()) {
                Object row[] = new Object[col];
                for (int i = 0; i < row.length; i++) {
                    row[i] = rs.getObject(i + 1);
                }
                dtm.addRow(row);
            }
            tbl.setModel(dtm);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
     public static void loadTable(JTable tbl, String tb, String columns,String flt) {
        connect("jdbc:mysql://localhost:3306/examscoring");
        dtm = new DefaultTableModel();
        try {
            sqlQuery = "SELECT " + columns + " FROM " + tb + " WHERE "+flt+";";
            rs = st.executeQuery(sqlQuery);
            md = rs.getMetaData();
            Integer col = md.getColumnCount();
            String column[] = new String[col];
            for (int i = 0; i < col; i++) {
                column[i] = md.getColumnName(i + 1);
                dtm.addColumn(column[i]);
            }
            while (rs.next()) {
                Object row[] = new Object[col];
                for (int i = 0; i < row.length; i++) {
                    row[i] = rs.getObject(i + 1);
                }
                dtm.addRow(row);
            }
            tbl.setModel(dtm);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean deleteRecord(String table, String filter) {
        boolean bool = false;
        connect("jdbc:mysql://localhost:3306/examscoring");
        try {
            sqlQuery = "DELETE  FROM " + table + " WHERE " + filter + "";
            int x = st.executeUpdate(sqlQuery);
            bool = (x > 0) ? true : false;
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return bool;
    }

    public static boolean updateRecord(String table, String updates, String filter) {
        boolean bool = false;
        connect("jdbc:mysql://localhost:3306/examscoring");
        try {
            sqlQuery = "UPDATE " + table + " SET " + updates + " WHERE " + filter + "";
            int x = st.executeUpdate(sqlQuery);
            bool = (x > 0) ? true : false;
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return bool;
    }

    public static boolean registerRecord(String table, String columns, String values) {
        boolean bool = false;
        connect("jdbc:mysql://localhost:3306/examscoring");
        try {
            sqlQuery = "INSERT INTO " + table + " (" + columns + ") VALUES (" + values + ")";
            int x = st.executeUpdate(sqlQuery);
            bool = (x > 0) ? true : false;
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return bool;
    }
//    getRandom(1, questnum,last[0].trim().length())

    public static Integer getRandom(Integer start, Integer end, Integer length) {
        Integer rnd = 0;
        Random rand;
        do {
            rand = new Random();
            String dff = rand.nextInt() + "";
            rnd = Integer.parseInt(dff.substring(2, 2 + length));
        } while (rnd >= end || rnd < start);
        return rnd;
    }
// </editor-fold>

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jPasswordField1 = new javax.swing.JPasswordField();
        jButton7 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Login Form");
        setResizable(false);

        jTextField1.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Username:");

        jLabel3.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Password:");

        jButton6.setBackground(new java.awt.Color(255, 255, 153));
        jButton6.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        jButton6.setText("Signin");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jPasswordField1.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        jPasswordField1.setEchoChar('#');

        jButton7.setBackground(new java.awt.Color(255, 255, 153));
        jButton7.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        jButton7.setText("Home");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField1, javax.swing.GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE)
                            .addComponent(jPasswordField1)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextField1)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        tst = new Test();
        amn = new Admin();
        reg = new RegisterPage();
        login();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        home = new ESS_BMSM_Home();
        ESS_BMSM_Home.display(home);
        ESS_BMSM_Home.hideMe(this);
    }//GEN-LAST:event_jButton7ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton6;
    public static javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    public static javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
