package db;


public class Vars {
// <editor-fold defaultstate="collapsed" desc="Class Variables">
    static boolean t=true,f=false,bool;
    static int date_time=1,date=0,time=2,time_stamp=3,month=4,year=5,week_year=6,week_month=7,day_week=8,day_month=9,day_year=10;
    static java.util.Calendar cl; static java.util.GregorianCalendar gc;
    static javax.swing.table.DefaultTableModel dtm;static javax.swing.JOptionPane jp = new javax.swing.JOptionPane();
    static java.sql.Connection con; static java.sql.Statement st; static java.sql.ResultSet rs; static java.sql.ResultSetMetaData md;
        static java.sql.DriverManager drm;
    static java.io.File fl,fls[]; static java.io.BufferedWriter bw;
    static java.io.BufferedReader br; static java.io.FileReader fr;
    static Object obj=null,objs[];
    static JavaDbCom fnc;
    static String db_con="jdbc:mysql://localhost:3306",db_user="root",db_pass="",db_name="",sql,classDriver="com.mysql.jdbc.Driver";
    static Integer yesOpt = jp.YES_OPTION, noOpt = jp.NO_OPTION, infoMsg = jp.INFORMATION_MESSAGE, warningMsg = jp.WARNING_MESSAGE, 
        questionMsg = jp.QUESTION_MESSAGE, yesNoOpt = jp.YES_NO_OPTION, okCancelOpt = jp.OK_CANCEL_OPTION, errorMsg = jp.ERROR_MESSAGE;
    
// </editor-fold>
}
