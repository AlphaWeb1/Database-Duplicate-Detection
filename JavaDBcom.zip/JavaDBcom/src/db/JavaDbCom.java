package db;


import java.io.File;

public class JavaDbCom {
    public static Vars vars;
    public JavaDbCom(String dbClassDriver,String dbConnectionURL,String dbUser,String dbPassword,String dbName) {
    vars.classDriver=dbClassDriver;vars.db_con=dbConnectionURL;vars.db_user=dbUser;vars.db_pass=dbPassword;
    vars.db_name=(dbName.trim().isEmpty()?"":dbName);if (!vars.db_con.toLowerCase().contains(dbName.toLowerCase())) {    vars.db_con+=dbName;}
    }
    JavaDbCom(){}
// <editor-fold defaultstate="collapsed" desc="Database Class JavaDbCom">
    // <editor-fold defaultstate="collapsed" desc="DML">
    /* Delete Methods */
    public static boolean delete(String tbl,String fields[],String vals[])/* Fixed Format Delete*/{
        boolean ret=vars.f;String where="";
        if (check_if_table_exists(tbl)==vars.f) {    messageBox("The table does not exist in this database", "Message", vars.errorMsg); return ret;   }
        if (fields.length!=vals.length) {  messageBox("The number of records must match number of fields", "Message", vars.warningMsg);ret=vars.f;
        }else{
            for (int i = 0; i < fields.length; i++) { if(i==0){where+=("`"+fields[i]+"`='"+vals[i]+"'");}else{where+=(" AND `"+fields[i]+"`='"+vals[i]+"'");} }
            vars.sql="DELETE FROM `"+tbl+"` WHERE "+where+";"; 
            try {  connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);vars.st.executeUpdate(vars.sql);
                ret=vars.t; //messageBox("Record successfully updated", "message", vars.infoMsg);
            } catch (Exception e) {e.printStackTrace();  messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); ret=vars.f; return ret;
            }
        }return ret;
    }
    public static boolean delete(String tbl,String where)/* Free Format Delete*/{
        boolean ret=vars.f;
        if (check_if_table_exists(tbl)==vars.f) {
            messageBox("The table does not exist in this database", "Message", vars.errorMsg); return ret; 
        }
        vars.sql="DELETE FROM "+tbl+" "+((where.isEmpty()==vars.t)?"":"WHERE "+where)+";"; 
            try {  connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);vars.st.executeUpdate(vars.sql);
                ret=vars.t; //messageBox("Record successfully updated", "message", vars.infoMsg);
            } catch (Exception e) {e.printStackTrace();  messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); ret=vars.f; return ret;
            }
        return ret;
    }
    /* Insert Methods */
    public static boolean insert(String tbl,String fields,String data)/* Free Format Columns and Records*/{
        boolean ret=vars.f;
        if (fields.replace(",", "\n").split("\n").length!=data.replace(",", "\n").split("\n").length) { 
            messageBox("The number of records must match number of fields", "Message", vars.warningMsg);ret=vars.f;
        }else{  vars.sql="INSERT INTO "+tbl+" ("+fields+") VALUES ("+data+");"; 
            try { connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);vars.st.executeUpdate(vars.sql);
                ret=vars.t; //messageBox("Record successfully added", "message", vars.infoMsg);
            } catch (Exception e) {e.printStackTrace(); messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg);  ret=vars.f; return ret;
            }
        }return ret;
    }
    public static boolean insert(String tbl,String fields[],String data[])/* Fixed Format Columns and Records*/{
        boolean ret=vars.f;
        if (check_if_table_exists(tbl)==vars.f) {
            messageBox("The table does not exist in this database", "Message", vars.errorMsg); return ret; 
        }
        if (fields.length!=data.length) {  messageBox("The number of records must match number of fields", "Message", vars.warningMsg);ret=vars.f;
        }else{  vars.sql="INSERT INTO `"+tbl+"` (";
            for (int i = 0; i < fields.length; i++) { if(i==0){vars.sql+=("`"+fields[i]+"`");}else{vars.sql+=(",`"+fields[i]+"`");} }
            vars.sql+=(") VALUES (");
            for (int i = 0; i < data.length; i++) { if(i==0){vars.sql+=("'"+data[i]+"'");}else{vars.sql+=(",'"+data[i]+"'");} } vars.sql+=(");");
            try {  connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);vars.st.executeUpdate(vars.sql);
                ret=vars.t; //messageBox("Record successfully added", "message", vars.infoMsg);
            } catch (Exception e) {e.printStackTrace(); messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg);  ret=vars.f; return ret;
            }
        }return ret;
    }
    /* Select Methods */
    public static String select_val(String tbl,String field,String where)/*Fixed Format Select Val*/{String ret=null;
        if (check_if_table_exists(tbl)==vars.f) {
            messageBox("The table does not exist in this database", "Message", vars.errorMsg); return ret; 
        }
        try {   connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
            vars.sql="SELECT `"+field+"` FROM `"+tbl+"` WHERE "+((where.isEmpty()==vars.t)?"":"WHERE "+where)+";";
            vars.rs=vars.st.executeQuery(vars.sql);
            while (vars.rs.next()) {  ret=vars.rs.getString(1);}
        } catch (Exception e) {  messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg);  ret=null; e.printStackTrace();
        }
        return ret;
    }
    public static String select_val2(String tbl,String field,String where)/*Free Format Select Val*/{String ret=null;
        if (check_if_table_exists(tbl)==vars.f) {
            messageBox("The table does not exist in this database", "Message", vars.errorMsg); return ret; 
        }
        try {   connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
            vars.sql="SELECT "+field+" FROM "+tbl+" WHERE "+((where.isEmpty()==vars.t)?"":"WHERE "+where)+";";
            vars.rs=vars.st.executeQuery(vars.sql);
            while (vars.rs.next()) {  ret=vars.rs.getString(1);}
        } catch (Exception e) {  messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg);  ret=null; e.printStackTrace();
        }
        return ret;
    }
    public static String[] select_col(String tbl,String field,String where)/*Fixed Format Select Col*/{ String ret[]=null;Integer count=0;
        if (check_if_table_exists(tbl)==vars.f) {
            messageBox("The table does not exist in this database", "Message", vars.errorMsg); return ret; 
        }
        try {   connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
            vars.sql="SELECT `"+field+"` FROM `"+tbl+"` "+((where.isEmpty()==vars.t)?"":"WHERE "+where)+";";
            vars.rs=vars.st.executeQuery(vars.sql);  while (vars.rs.next()) { count++; }
            vars.rs=vars.st.executeQuery(vars.sql);  ret=new String[count]; count=0;
            while (vars.rs.next()) { ret[count]=vars.rs.getString(1); count++; }
        } catch (Exception e) {  messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); ret=null; e.printStackTrace();
        }
        return ret;
    }
    public static String[] select_col2(String tbl,String field,String where)/*Free Format Select Col*/{ String ret[]=null;Integer count=0;
        if (check_if_table_exists(tbl)==vars.f) {
            messageBox("The table does not exist in this database", "Message", vars.errorMsg); return ret; 
        }
        try {   connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
            vars.sql="SELECT "+field+" FROM "+tbl+" "+((where.isEmpty()==vars.t)?"":"WHERE "+where)+";";
            vars.rs=vars.st.executeQuery(vars.sql);  while (vars.rs.next()) { count++; }
            vars.rs=vars.st.executeQuery(vars.sql);  ret=new String[count]; count=0;
            while (vars.rs.next()) { ret[count]=vars.rs.getString(1); count++; }
        } catch (Exception e) {  messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); ret=null; e.printStackTrace();
        }
        return ret;
    }
    public static String[] select_row(String tbl,String fields[],String where)/*Fixed Format Select Row*/{ String cols="",ret[]=null;Integer cnt=0;
        if (check_if_table_exists(tbl)==vars.f) {    messageBox("The table does not exist in this database", "Message", vars.errorMsg); return ret; 
        }
        try {   connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
        for (int i = 0; i < fields.length; i++) { if(i==0){cols+=("`"+fields[i]+"`");}else{cols+=(",`"+fields[i]+"`");} }
            vars.sql="SELECT "+cols+" FROM `"+tbl+"` "+((where.isEmpty()==vars.t)?"":"WHERE "+where)+";";
            vars.rs=vars.st.executeQuery(vars.sql);  vars.md=vars.rs.getMetaData(); 
            ret=new String[vars.md.getColumnCount()];
            while (vars.rs.next()) {if(cnt==1){messageBox("This query returns multiple records use method 'db_query_recs'", "Message", vars.errorMsg); 
            break;} for(int i=0;i<ret.length;i++){ret[i]=vars.rs.getString(i+1);}  cnt++; }
        } catch (Exception e) {  messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); ret=null; e.printStackTrace();
        }  return ret;
    }
    public static String[] select_row2(String tbl,String fields,String where)/*Free Format Select Row*/{ String ret[]=null;Integer cnt=0;
        if (check_if_table_exists(tbl)==vars.f) {    messageBox("The table does not exist in this database", "Message", vars.errorMsg); return ret; 
        }
        try {   connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
            vars.sql="SELECT "+fields+" FROM "+tbl+" "+((where.isEmpty()==vars.t)?"":"WHERE "+where)+";";
            vars.rs=vars.st.executeQuery(vars.sql); vars.md=vars.rs.getMetaData(); 
            ret=new String[vars.md.getColumnCount()];
            while (vars.rs.next()) {if(cnt==1){messageBox("This query returns multiple records use method 'db_query_recs'", "Message", vars.errorMsg); 
            break;} for(int i=0;i<ret.length;i++){ret[i]=vars.rs.getString(i+1);}  cnt++; }
        } catch (Exception e) {  messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); ret=null; e.printStackTrace();
        }
        return ret;
    }
    public static String[][] select_recs(String tbl,String fields[],String where)/*Fixed Format Select Records*/{String cols="",ret[][]=null;
        Integer count=0,col_count;
        if (check_if_table_exists(tbl)==vars.f) {    messageBox("The table does not exist in this database", "Message", vars.errorMsg); return ret;  }
        try {  connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
            for (int i = 0; i < fields.length; i++) { if(i==0){cols+=("`"+fields[i]+"`");}else{cols+=(",`"+fields[i]+"`");} }
            vars.sql="SELECT "+cols+" FROM `"+tbl+"` "+((where.isEmpty()==vars.t)?"":"WHERE "+where)+";"; 
            vars.rs=vars.st.executeQuery(vars.sql);  while (vars.rs.next()) { count++; }
            vars.rs=vars.st.executeQuery(vars.sql);vars.md=vars.rs.getMetaData();
            ret=new String[count][(col_count=vars.md.getColumnCount())]; count=0;
            while (vars.rs.next()) {  for(int i=0;i<col_count;i++){ ret[count][i]=vars.rs.getString(i+1);} count++; }
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); ret=null; e.printStackTrace();
        }  return ret;
    }
    public static String[][] select_recs2(String tbl,String fields,String where)/*Free Format Select Records*/{String ret[][]=null;Integer count=0,col_count;
        if (check_if_table_exists(tbl)==vars.f) {    messageBox("The table does not exist in this database", "Message", vars.errorMsg); return ret; 
        }
        try {  connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
            vars.sql="SELECT "+fields+" FROM "+tbl+" "+((where.isEmpty()==vars.t)?"":"WHERE "+where)+";"; 
            vars.rs=vars.st.executeQuery(vars.sql);  while (vars.rs.next()) { count++; }
            vars.rs=vars.st.executeQuery(vars.sql);vars.md=vars.rs.getMetaData();
            ret=new String[count][(col_count=vars.md.getColumnCount())]; count=0;
            while (vars.rs.next()) {  for(int i=0;i<col_count;i++){ ret[count][i]=vars.rs.getString(i+1);} count++; }
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); ret=null; e.printStackTrace();
        }
        return ret;
    }
    /* Data Query Methods */
    public static String[][] db_query_recs(String query)/*Free Format Query Records*/{String ret[][];Integer count=0,col_count;
        try {
            connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
            vars.sql=query; vars.rs=vars.st.executeQuery(vars.sql);  while (vars.rs.next()) { count++; }
            vars.rs=vars.st.executeQuery(vars.sql);vars.md=vars.rs.getMetaData();
            ret=new String[count][(col_count=vars.md.getColumnCount())]; count=0;
            while (vars.rs.next()) {  for(int i=0;i<col_count;i++){ ret[count][i]=vars.rs.getString(i+1);} count++; }
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); ret=null; e.printStackTrace();
        }  return ret;
    }
    public static String[] db_query_row(String query)/*Free Format Query Row*/{String ret[]; Integer cnt=0;
        try {
            connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
            vars.sql=query;
            vars.rs=vars.st.executeQuery(vars.sql);vars.md=vars.rs.getMetaData();
            ret=new String[vars.md.getColumnCount()]; 
            while (vars.rs.next()) { if(cnt==1){messageBox("This query returns multiple records use method 'db_query_recs'", "Message", vars.errorMsg); 
            break;} for(int i=0;i<ret.length;i++){ret[i]=vars.rs.getString(i+1);}  cnt++;}
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg);  ret=null; e.printStackTrace();
        }
        return ret;
    }
    public static String[] db_query_col(String query)/*Free Format Query Col*/{ String ret[];Integer count=0;
        try {
            connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
            vars.sql=query;
            vars.rs=vars.st.executeQuery(vars.sql);  while (vars.rs.next()) { count++; }
            vars.rs=vars.st.executeQuery(vars.sql);  ret=new String[count]; count=0;
            while (vars.rs.next()) { ret[count]=vars.rs.getString(1); count++; }
        } catch (Exception e) {  messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); ret=null; e.printStackTrace();
        }
        return ret;
    }
    public static String db_query_val(String query)/*Free Format Query Val*/{String ret="";
        try {
            connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
            vars.sql=query;
            vars.rs=vars.st.executeQuery(vars.sql);
            while (vars.rs.next()) {  ret=vars.rs.getString(1);}
        } catch (Exception e) {  messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg);  ret=null; e.printStackTrace();
        }
        return ret;
    }
    /* Update Metrhods */
    public static boolean update(String tbl,String sets,String where)/* Free Format Update*/{
        boolean ret=vars.f;
        if (check_if_table_exists(tbl)==vars.f) {
            messageBox("The table does not exist in this database", "Message", vars.errorMsg); return ret; 
        }
            vars.sql="UPDATE "+tbl+" SET "+sets+" "+((where.isEmpty()==vars.t)?"":"WHERE "+where)+";"; 
            try {
                connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);vars.st.executeUpdate(vars.sql);
                ret=vars.t; //messageBox("Record successfully updated", "message", vars.infoMsg);
            } catch (Exception e) {e.printStackTrace();  messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); ret=vars.f; return ret;
            }
        return ret;
    }
    public static boolean update(String tbl,String sets[],String vals[],String where)/* Fixed Format Update*/{
        boolean ret=vars.f;
        if (check_if_table_exists(tbl)==vars.f) {
            messageBox("The table does not exist in this database", "Message", vars.errorMsg); return ret; 
        }
        if (sets.length!=vals.length) {  messageBox("The number of values must match number of fields", "Message", vars.warningMsg);ret=vars.f;
        }else{vars.sql="UPDATE `"+tbl+"` SET ";
            for (int i = 0; i < sets.length; i++) { if(i==0){vars.sql+=("`"+sets[i]+"`='"+vals[i]+"'");}else{vars.sql+=(",`"+sets[i]+"`='"+vals[i]+"'");} }
            vars.sql+=" "+((where.isEmpty()==vars.t)?"":"WHERE "+where)+";"; 
            try {  connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);vars.st.executeUpdate(vars.sql);
                ret=vars.t; //messageBox("Record successfully updated", "message", vars.infoMsg);
            } catch (Exception e) {e.printStackTrace();  messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); ret=vars.f; return ret;
            }
        }return ret;
    }
    /* Free Format Manipulation Query */
    public static boolean db_execute(String query){
        boolean ret=vars.f; vars.sql=query;
            try {   connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);   vars.st.executeUpdate(vars.sql); ret=vars.t; 
            //messageBox("Query successfully executed", "message", vars.infoMsg);
            } catch (Exception e) {e.printStackTrace();  messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); ret=vars.f; return ret;
            } return ret;
    }
    // </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="DDL">
    /* Alter Table Methods */
    public static void alter_table_AI(String tbl,Integer increment){
        if (check_if_table_exists(tbl)==vars.f) {  messageBox("The table does not exist in this database", "Message", vars.errorMsg); return;   }
        if (!tbl.contains("`")) { tbl="`"+tbl+"`"; }
        vars.sql="ALTER TABLE "+tbl+" auto_increment = "+increment+";";
        try { connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass); 
           vars.st.executeUpdate(vars.sql); //messageBox("Query successfully executed", "message", vars.infoMsg);
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace();
        }
    }
    public static void alter_table_Add(String tbl,String field,String attributes ){
        if (check_if_table_exists(tbl)==vars.f) {  messageBox("The table does not exist in this database", "Message", vars.errorMsg); return;   }
        if (!tbl.contains("`")) { tbl="`"+tbl+"`"; }if (!field.contains("`")) { field="`"+field+"`"; }
        vars.sql="ALTER TABLE "+tbl+" ADD "+field+" "+attributes+";";
        try { connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass); 
           vars.st.executeUpdate(vars.sql); //messageBox("Query successfully executed", "message", vars.infoMsg);
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace();
        }
    }
    public static void alter_table_Change(String tbl,String field,String new_name,String attributes ){
        if (check_if_table_exists(tbl)==vars.f) {  messageBox("The table does not exist in this database", "Message", vars.errorMsg); return;   }
        if (!tbl.contains("`")) { tbl="`"+tbl+"`"; }if (!field.contains("`")) { field="`"+field+"`"; }
        if (new_name.isEmpty()){new_name=field;}else if(!new_name.contains("`")) { new_name="`"+new_name+"`"; }
        vars.sql="ALTER TABLE "+tbl+" CHANGE "+field+" "+new_name+" "+attributes+";";
        try { connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass); 
           vars.st.executeUpdate(vars.sql); //messageBox("Query successfully executed", "message", vars.infoMsg);
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace();
        }
    }
    public static void alter_table_Drop(String tbl,String field ){
        if (check_if_table_exists(tbl)==vars.f) {  messageBox("The table does not exist in this database", "Message", vars.errorMsg); return;   }
        if (!tbl.contains("`")) { tbl="`"+tbl+"`"; }if (!field.contains("`")) { field="`"+field+"`"; }
        vars.sql="ALTER TABLE "+tbl+" DROP "+field+";";
        try { connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass); 
           vars.st.executeUpdate(vars.sql); //messageBox("Query successfully executed", "message", vars.infoMsg);
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace();
        }
    }
    /* Create Methods */
    public static boolean create_db(String classDriver,String db_server,String db_name,String db_user,String db_pass){ 
        boolean ret=vars.f;String dbn=db_name;
        if (check_if_db_exists(classDriver,db_server,db_name,db_user,db_pass)==vars.t) {
            messageBox("A database already exist with this name '"+db_name+"'", "Message", vars.errorMsg); return ret; 
        }if (!db_name.contains("`")) { dbn="`"+db_name+"`";   }
        vars.sql="CREATE DATABASE IF NOT EXISTS "+dbn+";";
        try { connect(classDriver,db_server, db_user, db_pass); 
           vars.st.executeUpdate(vars.sql); ret=vars.t; //messageBox("Query successfully executed", "message", vars.infoMsg);
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace(); ret=vars.f; return ret;
        } return ret;
    }
    public static void create_table(String tbl,String fields[],String constrs)/* Free Format Create Table*/{
        if (check_if_table_exists(tbl)==vars.t) {
            messageBox("A table already exist with this name '"+tbl+"'", "Message", vars.errorMsg); return; 
        }
        vars.sql="CREATE TABLE IF NOT EXISTS "+tbl+" (\n";
        for (String field : fields) {
            vars.sql+=(field+",\n");
        } vars.sql+=(constrs+") ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;");
        try { connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass); 
           vars.st.executeUpdate(vars.sql); //messageBox("Query successfully executed", "message", vars.infoMsg);
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace();
        }
//        print(vars.sql);
    }
    public static void create_table(String tbl,String fields[],String attribs[],String constrs)/* Fixed Format Create Table*/{
        if (check_if_table_exists(tbl)==vars.t) {
            messageBox("A table already exist with this name '"+tbl+"'", "Message", vars.errorMsg); return; 
        }
        if (fields.length!=attribs.length) {
            messageBox("The number of records must match number of fields", "Message", vars.warningMsg);return;
        }
        vars.sql="CREATE TABLE IF NOT EXISTS "+tbl+" (\n";int i=0;
        for (String field : fields) {
            vars.sql+=(field+" "+attribs[i]+",\n");i++;
        } vars.sql+=(constrs+") ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;");
        try { connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass); 
           vars.st.executeUpdate(vars.sql); //messageBox("Query successfully executed", "message", vars.infoMsg);
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace();
        }
//        print(vars.sql);
    }
    /* Drop Methods */
    public static void drop_table(String tbl){
        if (check_if_table_exists(tbl)==vars.f) {  messageBox("The table does not exist in this database", "Message", vars.errorMsg); return;   }
        if (!tbl.contains("`")) { tbl="`"+tbl+"`"; } 
        vars.sql="DROP TABLE "+tbl+";";
        try { connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass); 
           vars.st.executeUpdate(vars.sql); //messageBox("Query successfully executed", "message", vars.infoMsg);
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace();
        }
    }
    public static boolean drop_db(String classDriver,String db_server,String db_name,String db_user,String db_pass){ 
        boolean ret=vars.f;String dbn=db_name;
        if (check_if_db_exists(classDriver,db_server,db_name,db_user,db_pass)==vars.f) {
            messageBox("The database does not exist in this server", "Message", vars.errorMsg); return ret; 
        }if (!db_name.contains("`")) { dbn="`"+db_name+"`";   } 
        vars.sql="DROP DATABASE "+dbn+";";
        try { connect(classDriver,db_server, db_user, db_pass); 
           vars.st.executeUpdate(vars.sql); ret=vars.t; //messageBox("Query successfully executed", "message", vars.infoMsg);
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace(); ret=vars.f; return ret;
        } return ret;
    }
    /* Rename Methods */
    public static void rename_table(String tbl,String tbl_new){
        if (check_if_table_exists(tbl)==vars.f) {  messageBox("The table does not exist in this database", "Message", vars.errorMsg); return;   }
        if (!tbl.contains("`")) { tbl="`"+tbl+"`"; } if (!tbl_new.contains("`")) { tbl_new="`"+tbl_new+"`"; }
        vars.sql="RENAME TABLE "+tbl+" TO "+tbl_new+";";
        try { connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass); 
           vars.st.executeUpdate(vars.sql); //messageBox("Query successfully executed", "message", vars.infoMsg);
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace();
        }
    }
    public static boolean rename_db(String classDriver,String db_server,String db_name,String new_db_name,String db_user,String db_pass){ 
        boolean ret=vars.f;String dbn=db_name;
        if (check_if_db_exists(classDriver,db_server,db_name,db_user,db_pass)==vars.f) {
            messageBox("The database does not exist in this server", "Message", vars.errorMsg); return ret; 
        }if (!db_name.contains("`")) { dbn="`"+db_name+"`";   } if (!new_db_name.contains("`")) { new_db_name="`"+new_db_name+"`";   }
        vars.sql="RENAME DATABASE "+dbn+" TO "+new_db_name+";";
        try { connect(classDriver,db_server, db_user, db_pass); 
           vars.st.executeUpdate(vars.sql); ret=vars.t; //messageBox("Query successfully executed", "message", vars.infoMsg);
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace(); ret=vars.f; return ret;
        } return ret;
    }
    /* Truncate Method */
    public static void truncate_table(String tbl){
        if (check_if_table_exists(tbl)==vars.f) {  messageBox("The table does not exist in this database", "Message", vars.errorMsg); return;   }
        if (!tbl.contains("`")) { tbl="`"+tbl+"`"; } 
        vars.sql="TRUNCATE TABLE "+tbl+";";
        try { connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass); 
           vars.st.executeUpdate(vars.sql); //messageBox("Query successfully executed", "message", vars.infoMsg);
        } catch (Exception e) { messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace();
        }
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Data Attachement Methods">
    public static boolean check_if_table_exists(String arg) {boolean ret=vars.f; String args=arg;
        if (arg.contains("`")) {  args=(arg.replace("`", " ")).trim();  }
        try { connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
            vars.sql="SHOW TABLES;";
            vars.rs=vars.st.executeQuery(vars.sql);
            while(vars.rs.next()){
            if(vars.rs.getString(1).equalsIgnoreCase(args)){ret=vars.t;} 
            }
        } catch (Exception e) {messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace();ret=vars.f;
        }return ret;
    }
    
    public static boolean check_if_db_exists(String classDriver,String db_server,String db_name,String db_user,String db_pass) {
        boolean ret=vars.f; String args=db_name;
        if (db_name.contains("`")) {  args=(db_name.replace("`", " ")).trim();  }
        try { connect(classDriver,db_server, db_user, db_pass);
            vars.sql="SHOW DATABASES;";
            vars.rs=vars.st.executeQuery(vars.sql);
            while(vars.rs.next()){
            if(vars.rs.getString(1).equalsIgnoreCase(args)){ret=vars.t;} 
            }
        } catch (Exception e) {messageBox("Database Server Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace();ret=vars.f;
        }return ret;
    }
    
    private static void connect(String classDriver,String cnt,String user, String pass) {
        try { Class.forName(classDriver);
            vars.con = vars.drm.getConnection(cnt, user, pass); vars.st = vars.con.createStatement();
        } catch (Exception e) {  e.printStackTrace();  }
    }
    
    public static boolean is_record_deleted(String tbl,String field,String where) {boolean ret=vars.f;
        if (check_if_table_exists(tbl)==vars.f) {   messageBox("The table does not exist in this database", "Message", vars.errorMsg); return ret;  }
        try {    connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
            vars.sql="SELECT COUNT("+field+") FROM "+tbl+" WHERE "+where+";";
            vars.rs=vars.st.executeQuery(vars.sql);
            while (vars.rs.next()) { if (vars.rs.getInt(1)<=0) { ret=vars.t; } }
        } catch (Exception e) {e.printStackTrace(); messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg);  ret=vars.f; return ret;
        }
        return ret;
    } 
            
    public static void load_tbl(String query,javax.swing.JTable jtb){ Integer count,i;
        try {vars.dtm=new javax.swing.table.DefaultTableModel();
            connect(vars.classDriver,vars.db_con, vars.db_user, vars.db_pass);
            vars.sql=query;
            vars.rs=vars.st.executeQuery(vars.sql);vars.md=vars.rs.getMetaData();
            count=vars.md.getColumnCount();vars.objs=new Object[count];
            for (i=0;i<count;i++) {  vars.dtm.addColumn(strCapTitled(vars.md.getColumnName(i+1)));  }
            while (vars.rs.next()) {  for(i=0;i<count;i++){vars.objs[i]=vars.rs.getObject(i+1);} vars.dtm.addRow(vars.objs); }
            jtb.setModel(vars.dtm);
        }catch (Exception e) {  messageBox("Database Error Check Stack Trace", "Message", vars.errorMsg); e.printStackTrace();
        }
    }
    public static void set_dbParams(String dbClassDriver,String dbConnectionURL,String dbUser,String dbPassword,String dbName)/* Set Database Connection Parameters*/
    { vars.classDriver=dbClassDriver;vars.db_con=dbConnectionURL;vars.db_user=dbUser;vars.db_pass=dbPassword;
        vars.db_name=(dbName.trim().isEmpty()?"":dbName);    if (!vars.db_con.toLowerCase().contains(dbName.toLowerCase())) {    vars.db_con+=dbName;}
    }
    public static String[] get_dbParams(String dbClassDriver,String dbConnectionURL,String dbUser,String dbPassword,String dbName)/* Get Database Connection Parameters*/
    {String strng[]={vars.classDriver,vars.db_con,vars.db_user,vars.db_pass,vars.db_name};   return strng; }
    // </editor-fold>
    
// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="Other Funcrions">
    public static Integer confirmBox(String message, String title, Integer ic) { return vars.jp.showConfirmDialog(null, message, title, vars.yesNoOpt, ic); }
    
    public static String deletFile(File fl) {  String msg = "false",str;
        if (fl.exists()) {  str = fl.getName();
            try { vars.bool = fl.delete();   if (vars.bool) msg = "File " + str + " Is Successfully Deleted";
                else msg = " File " + str + " Cannot Be Deleted";
            } catch (Exception e) {  e.printStackTrace();   }
        }   return msg;
    }
    
    public static String get_date(int type){String result=null;
        vars.gc=new java.util.GregorianCalendar();
        if (type==0) {
            result=vars.gc.get(vars.cl.YEAR)+"-"+(vars.gc.get(vars.cl.MONTH)+1)+"-"+vars.gc.get(vars.cl.DAY_OF_MONTH);
        }else if(type==1){
            result=vars.gc.get(vars.cl.YEAR)+"-"+(vars.gc.get(vars.cl.MONTH)+1)+"-"+vars.gc.get(vars.cl.DAY_OF_MONTH)+" "+
                    vars.gc.get(vars.cl.HOUR_OF_DAY)+":"+vars.gc.get(vars.cl.MINUTE)+":"+vars.gc.get(vars.cl.SECOND);
        }else if(type==2){
            result=vars.gc.get(vars.cl.HOUR_OF_DAY)+":"+vars.gc.get(vars.cl.MINUTE)+":"+vars.gc.get(vars.cl.SECOND);
        }
        return result;
    }

    public static String inputBox(String message, String title, Integer ic) { return vars.jp.showInputDialog(null, message, title, ic);  }
 
    public static void messageBox(String message, String title, Integer ic) { vars.jp.showMessageDialog(null, message, title, ic); }
    
    public static String multiWordCapz(String obje){    String new_str="";String obj[]=obje.split(" ");
        for (int i=0;i<obj.length;i++) {  if(i==0) new_str+=(toCapitalize(obj[i])); else new_str+=" "+(toCapitalize(obj[i]));  }   return new_str;
    }
    
    public static void print(Object obj) {  System.out.println(obj); }
    
    public static void runFile(String fl) {   try {   Process p = Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+fl);  p.waitFor();
    } catch (Exception ex) {   ex.printStackTrace();   }  }
    
    public static String strCapTitled(String obje){
        String new_str="";String obj[]=obje.split("_");
        for (int i=0;i<obj.length;i++) {
            if(i==0) new_str+=(toCapitalize(obj[i])); else new_str+=" "+(toCapitalize(obj[i]));
        }
        return new_str;
    }
    
    public static String toCapitalize(String obj) {
        if(!obj.isEmpty()) return ((obj.charAt(0) + "").trim().toUpperCase() + obj.substring(1, obj.length()).toLowerCase());   else return "false";
    }
// </editor-fold>
}
