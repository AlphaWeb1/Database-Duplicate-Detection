/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pc_tu;

import java.awt.Shape;
import javafx.scene.shape.Circle;

/**
 *
 * @author hp
 */
public class PC_TU {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new PC_TU_Home().setVisible(true);
        new TimingCheck();
        Circle cc=new Circle(60, 60, 60);
    }
    
}
